<!DOCTYPE html>
<html>
<head>
	<title>latihan 10</title>
</head>
<body>
	<?php
		$x = 15;
		$x %= 4;
		echo $x;
	?>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="halaman">
		<h2>HALAMAN DEPAN</h2>
			<p>SELAMAT DATANG DI Pembelajaran WEB II PIKSI INI MERUPAKAN HALAMAN DEPAN PADA DEMO CARA MEMBUAT HALAMAN WEB DINAMIS</p>
		</div>
</body>
</html>
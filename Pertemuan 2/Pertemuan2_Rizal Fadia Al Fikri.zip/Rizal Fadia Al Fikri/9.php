<!DOCTYPE html>
<html>
<head>
	<title>latihan 9</title>
</head>
<body>
	<?php
		$x = 10;
		$y = 6;
		echo $x + $y;
	?>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title>latihan 6</title>
</head>
<body>
	<?php 
		$x = 10.365;
		var_dump($x);
	?> 
</body>
</html>
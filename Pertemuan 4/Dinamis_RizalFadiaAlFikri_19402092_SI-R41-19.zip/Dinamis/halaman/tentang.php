<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="halaman">
		<h2>TENTANG KAMI</h2>
		<p>INI ADALAH HALAMAN TENTANG KAMI</p>
		<p>WEB 2 ADALAH PEMBELAJARAN MENGENAI WEB</p>
	</div>
</body>
</html>
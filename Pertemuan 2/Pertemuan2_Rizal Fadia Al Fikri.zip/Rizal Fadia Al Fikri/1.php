<!DOCTYPE html>
<html>
<head>
	<title>Latihan 1</title>
</head>
<body>
	<h1>My First PHP</h1>
	<?php echo "Hello World"; ?>
</body>
</html>

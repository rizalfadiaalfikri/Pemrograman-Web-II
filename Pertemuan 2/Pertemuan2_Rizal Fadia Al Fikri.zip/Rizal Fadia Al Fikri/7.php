<!DOCTYPE html>
<html>
<head>
	<title>Latihan 7</title>
</head>
<body>
	<?php
		$cars = array("Volvo","BMW","Toyota");
		var_dump($cars);
	?>
</body>
</html>
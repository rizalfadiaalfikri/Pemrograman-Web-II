<!DOCTYPE html>
<html>
<head>
	<title>latihan 18</title>
</head>
<body>
	<?php 
		for ($x=0; $x <= 10 ; $x++) { 
			echo "The number is : $x <br>";
		}
	 ?>
</body>
</html>
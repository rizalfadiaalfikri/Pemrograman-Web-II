<!DOCTYPE html>
<html>
<head>
	<title>MEMBUAT Login DENGAN PHP DAN MySQL |MALASNGODING.com</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="login">
		<form action="login.php" method="post">
			<h3>LOGIN</h3>
			<input placeholder="Username" type="text" name="username" />
			<input placeholder="Password" type="password" name="password" />
			<button class="btn" name="login">Log in</button>
		</form>
	</div>
</body>
</html>
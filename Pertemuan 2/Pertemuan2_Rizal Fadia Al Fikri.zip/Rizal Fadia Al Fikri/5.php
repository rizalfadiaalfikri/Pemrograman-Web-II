<!DOCTYPE html>
<html>
<head>
	<title>Latihan 5</title>
</head>
<body>
	<?php 
		$x = 10.365;
		var_dump($x);
	 ?>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title>Latihan 2</title>
</head>
<body>
	<?php 

		$txt = "Hello World";
		$x = 5;
		$y = 10.5;

		echo $txt;
		echo "<br>";
		echo $x;
		echo "<br>";
		echo $y;

	 ?>
</body>
</html>
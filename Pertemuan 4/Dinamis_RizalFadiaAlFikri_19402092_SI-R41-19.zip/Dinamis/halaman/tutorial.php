<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="halaman">
		<h2>HALAMAN TUTORIAL</h2>
		<p>INI ADALAH HALAMAN TUTORIAL</p>
	</div>
</body>
</html>
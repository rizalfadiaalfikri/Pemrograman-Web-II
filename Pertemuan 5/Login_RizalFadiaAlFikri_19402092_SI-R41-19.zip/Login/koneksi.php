<?php 
	// Koneksi Ke Database
	mysql_connect("localhost","root","");//SESUAIKANDENGANPASSWORDDANUSERNAME mysql ANDA
	mysql_select_db("malasngoding");//NAMA DATABASE YANG KITA GUNAKAN 4 ?>

 ?>
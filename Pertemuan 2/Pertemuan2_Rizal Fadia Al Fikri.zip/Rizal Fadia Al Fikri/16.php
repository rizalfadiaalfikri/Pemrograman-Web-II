<!DOCTYPE html>
<html>
<head>
	<title>latihan 16</title>
</head>
<body>
	<?php
		$x = 1;
		while($x <= 5) {
		echo "The number is: $x <br>";
		$x++;
		}
	?>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title>latihan 17</title>
</head>
<body>
	<?php
		$x = 1;
		do {
			echo "The number is: $x <br>";
			$x++;
		} while ($x <= 5);
	?>
</body>
</html>
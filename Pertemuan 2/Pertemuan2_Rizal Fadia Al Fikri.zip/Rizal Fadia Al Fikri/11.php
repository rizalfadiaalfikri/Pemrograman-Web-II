<!DOCTYPE html>
<html>
<head>
	<title>latihan 11</title>
</head>
<body>
	<?php
		$x = 100;
		$y = "100";
		var_dump($x == $y); // returns true because values are equal
	?>
</body>
</html>